<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::resource('category', CategoryController::class);
Route::resource('products', ProductController::class);
Route::resource('students', StudentController::class);
Route::resource('Admin', UserController::class);


Route::middleware(['auth'])->group(function () {
    // Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/category', [CategoryController::class, 'index'])->name('category.index');
    Route::get('/products', [ProductController::class, 'index'])->name('products.index');
    Route::get('/students', [StudentController::class, 'index'])->name('students.index');
});




Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::resource('users', UserController::class);
    Route::get('/admin/index', [UserController::class, 'index'])->name('Admin.index');
    Route::get('/admin/index1', [UserController::class, 'index1'])->name('Admin.index1');



    Route::patch('products/{id}/toggle-status', [ProductController::class, 'toggleStatus'])->name('products.toggleStatus');
    Route::patch('category/{id}/toggle-status', [CategoryController::class, 'toggleStatus'])->name('category.toggleStatus');
    Route::get('categories/export', [CategoryController::class, 'export'])->name('categories.export');
});

require __DIR__ . '/auth.php';

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Student
                            <a href="<?php echo e(route('students.index')); ?>" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('students.update', $student->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?> <!-- Add this line for updating -->

                            <div class="row">
                                <div class="col-lg-6">
                                    <label>First Name</label>
                                    <input type=" text" class="form-control" name="first_name"
                                        placeholder="Enter first name" value="<?php echo e(old('first_name', $student->first_name)); ?>"
                                        required />
                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6">
                                    <label>Last Name</label>
                                    <input type=" text" class="form-control" name="last_name"
                                        placeholder="Enter last name" value="<?php echo e(old('last_name', $student->last_name)); ?>"
                                        required />
                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Email</label>
                                    <input type=" email" class="form-control" name="email"
                                        placeholder="Enter email address" value="<?php echo e(old('email', $student->email)); ?>"
                                        required />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6">
                                    <label>Password</label>
                                    <input type=" password" class="form-control" name="password"
                                        placeholder="Enter password" />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <small class="form-text text-muted">Leave blank to keep current password.</small>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Phone Number</label>
                                    <input type=" text" class="form-control" name="phone_number"
                                        placeholder="Enter phone number"
                                        value="<?php echo e(old('phone_number', $student->phone_number)); ?>" required />
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6">
                                    <label>Type</label>
                                    <select class="form-select" name="role" required>
                                        <option value="" disabled>Select Type</option>
                                        <option value="user"
                                            <?php echo e(old('role', $student->role) == 'user' ? 'selected' : ''); ?>>User</option>
                                        <option value="admin"
                                            <?php echo e(old('role', $student->role) == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                    </select>
                                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Address</label>
                                    <textarea name="address" rows="3" class="form-control" placeholder="Enter address" required><?php echo e(old('address', $student->address)); ?></textarea>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6">
                                    <label>Bio</label>
                                    <textarea name="bio" rows="3" class="form-control" placeholder="Enter bio"><?php echo e(old('bio', $student->bio)); ?></textarea>
                                </div>

                            </div>

                            <div class="row mt-3">
                                <div class="col-lg-3">
                                    <label>Profile Image</label>
                                    <?php if($student->profile_picture): ?>
                                        <div class="mb-2">
                                            <img src="<?php echo e(asset($student->profile_picture)); ?>" alt="Current Profile Image"
                                                style="width: 100px; height: auto;" />
                                        </div>
                                    <?php else: ?>
                                        <p>No current Image.</p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-lg-9">
                                    <label>Profile Image(optional)</label>
                                    <input type="file" class="form-control" style="border: 1px solid gray; padding: 8px;"
                                        name="profile_picture" accept="image/*" />
                                    <?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <small class="form-text text-muted">Leave blank to keep current picture.</small>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-lg-12 text-end">
                                    <button type="submit" class="btn btn-primary">
                                        Update
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .row {
        padding: 10px;
    }
</style>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/student/edit.blade.php ENDPATH**/ ?>
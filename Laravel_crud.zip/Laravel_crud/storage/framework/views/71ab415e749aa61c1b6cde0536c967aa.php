<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 m-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>Product Details
                            <a href="<?php echo e(url('products')); ?>" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4">
                                <label>Product Image</label>
                                <div>
                                    <img src="<?php echo e(asset($product->image)); ?>" alt="Product Image"
                                        style="width: 100px; height: auto;" />
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <label>Name</label>
                                <p><?php echo e($product->name); ?></p>
                            </div>
                            <div class="col-lg-4">
                                <label>Category</label>
                                <p><?php echo e($product->category->name); ?></p> <!-- Assuming category is an object -->
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-lg-12">
                                <label>Description</label>
                                <p><?php echo e($product->description); ?></p>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-lg-4">
                                <label>Price ($)</label>
                                <p><?php echo e(number_format($product->price, 2)); ?></p>
                            </div>
                            <div class="col-lg-4">
                                <label>Discount (%)</label>
                                <p><?php echo e($product->discount ?? 'N/A'); ?></p>
                            </div>
                            <div class="col-lg-4">
                                <label>Discounted Price</label>
                                <p><?php echo e(number_format($product->price - ($product->price * $product->discount) / 100, 2)); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    label {
        font-weight: bold;
    }

    .row {
        padding: 10px;
    }
</style>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/product/show.blade.php ENDPATH**/ ?>
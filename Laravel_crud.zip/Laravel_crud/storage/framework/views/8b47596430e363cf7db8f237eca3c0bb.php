<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">


                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4>User List</h4>

                    </div>

                    <div class="card-body">

                        <table class="table table-striped table-bordered">
                            <thead class="table-light" style="text-align: center;">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody style="text-align: center;">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->role); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        @


                    </div>
                </div>
            </div>
        </div>
    </div>


    <style>
        .row {
            padding: 10px;
        }

        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }

        .no-records {
            padding: 20px;
            border: 1px solid #ffc107;
            border-radius: 5px;
            background-color: #fff3cd;
            color: #856404;
            margin-top: 20px;
            font-weight: bold;
            font-size: 1.2rem;
            text-align: center;
        }
    </style>


    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4>Product List</h4>
                    </div>

                    <div class="card-body">

                        <table class="table table-striped table-bordered">
                            <thead style="text-align: center;">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Image</th>
                                    <th>Price (MRP)</th>
                                    <th>Discount</th>
                                    <th>Discounted Price</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody style="text-align: center;">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td><?php echo e($product->category ? $product->category->name : 'N/A'); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($product->image)); ?>" alt="Product Image"
                                                style="width: 100px; padding:5px; height: 100px; margin:auto;" />
                                        </td>
                                        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                        <td><?php echo e($product->discount ? $product->discount . '%' : 'N/A'); ?></td>
                                        <td style="text-align: center;">
                                            $<?php echo e(number_format($product->price - ($product->price * $product->discount) / 100, 2)); ?>

                                        </td>
                                        <td><?php echo e($product->status == 1 ? 'Active' : 'Inactive'); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .no-records {
        padding: 20px;
        border: 1px solid #ffc107;
        border-radius: 5px;
        background-color: #fff3cd;
        color: #856404;
        margin-top: 20px;
        font-weight: bold;
        font-size: 1.2rem;
        text-align: center;
    }
</style>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/Admin/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-lg border-0 rounded">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Student Details</h4>
                    </div>
                    <div class="card-body">
                        <div class="row align-items-center m-auto">
                            <div class="col-md-4 text-center ">
                                <?php if($student->profile_picture): ?>
                                    <img src="<?php echo e(asset($student->profile_picture)); ?>" alt="Profile Image"
                                        class="rounded-circle m-auto" style="width: 200px; height: 200px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('default-profile.png')); ?>" alt="Default Image" class="rounded-circle"
                                        style="width: 100px; height: 100px;">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <h5><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h5>
                                <p class="text-muted"><?php echo e($student->email); ?></p>
                                <div>
                                    <strong>Phone Number:</strong> <?php echo e($student->phone_number); ?><br>
                                    <strong>Type:</strong> <?php echo e(ucfirst($student->role)); ?><br>
                                    <strong>Address:</strong> <?php echo e($student->address); ?><br>
                                    <strong>Bio:</strong> <?php echo e($student->bio); ?>

                                </div>
                            </div>
                        </div>
                        <div class="text-end mt-3">
                            <a href="<?php echo e(route('students.index')); ?>" class="btn btn-danger">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    body {
        background-color: #f8f9fa;
    }

    .card {
        border-radius: 15px;
    }

    .card-header {
        font-size: 1.5rem;
        font-weight: bold;
    }

    .text-muted {
        font-size: 0.9rem;
    }

    .mb-3 {
        margin-bottom: 1.5rem !important;
    }

    .rounded-circle {
        border: 3px solid #007bff;
    }
</style>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/student/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="m-0 text-white">User List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->role); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="<?php echo e(route('Admin.index')); ?>" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="m-0 text-white">Product List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Price (MRP)</th>
                                    <th>Discount</th>
                                    <th>Discounted Price</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($product->image)); ?>" alt="Product Image"
                                                class="product-image" />
                                        </td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td><?php echo e($product->category ? $product->category->name : 'N/A'); ?></td>
                                        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                        <td><?php echo e($product->discount ? $product->discount . '%' : 'N/A'); ?></td>
                                        <td>$<?php echo e(number_format($product->price * (1 - $product->discount / 100), 2)); ?></td>
                                        <td><?php echo e($product->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="m-0 text-white">Category List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->description); ?></td>
                                        <td><?php echo e($category->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header">
                        <h4>Student List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Profile Image</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Address</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($student->id); ?></td>
                                        <td><?php echo e($student->first_name); ?></td>
                                        <td><?php echo e($student->last_name); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($student->profile_picture)); ?>" alt="Profile Picture"
                                                class="Student-image" />
                                        </td>
                                        <td><?php echo e($student->email); ?></td>
                                        <td><?php echo e($student->phone_number); ?></td>

                                        <td><?php echo e($student->address); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="<?php echo e(route('students.index')); ?>" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .card {
            border-radius: 15px;
            transition: transform 0.2s;
        }

        .card:hover {
            transform: scale(1.02);
        }

        .card-header {
            background: linear-gradient(to right, #4e73df, #224abe);
            color: white;
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: #f8f9fa;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .product-image,
        .Student-image {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            margin: auto;
            border: 1px solid #007bff;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s, color 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            color: white;
        }

        img.img-fluid {
            width: 100px;
            height: auto;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .card-header h4 {
                font-size: 1.2rem;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/Admin/index1.blade.php ENDPATH**/ ?>
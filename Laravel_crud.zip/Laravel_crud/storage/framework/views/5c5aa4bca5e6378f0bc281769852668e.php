 <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
        <?php echo e(__('Products')); ?>

    </h2>
 <?php $__env->endSlot(); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(session('Status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="flash-alert"
                        style="position: relative; padding: 20px; border-radius: 5px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; margin-bottom: 20px; z-index: 1000;">
                        <strong>Success!</strong> <?php echo e(session('Status')); ?>

                        <button type="button" class="close" aria-label="Close"
                            style="position: absolute; top: 2px; right: 20px; font-size: 40px; color: #155724;"
                            onclick="hideAlert()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script>
                        function hideAlert() {
                            $('#flash-alert').fadeOut();
                        }
                        setTimeout(hideAlert, 2000);
                    </script>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4>Product List</h4>
                        <a href="<?php echo e(url('products/create')); ?>" class="btn btn-primary">Add Product</a>
                    </div>

                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('products.index')); ?>" class="mb-3" id="searchForm">
                            <div class="row">
                                <div class="col-lg-4">
                                    <input name="name" class="form-control" placeholder="Search by name"
                                        value="<?php echo e(request('name')); ?>">
                                </div>
                                <div class="col-lg-4">
                                    <input name="category" class="form-control" placeholder="Search by category"
                                        value="<?php echo e(request('category')); ?>">
                                </div>
                                <div class="col-lg-2">
                                    <select name="status" class="form-select">
                                        <option value="" disabled selected>Search by status</option>
                                        <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Active
                                        </option>
                                        <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>Inactive
                                        </option>
                                    </select>
                                </div>
                                <div class="col-lg-1">
                                    <button class="btn btn-outline-primary w-100" type="submit">Search</button>
                                </div>
                                <div class="col-lg-1">
                                    <button class="btn btn-secondary w-100" type="button" id="cancelButton">Cancel</button>
                                </div>
                            </div>
                        </form>


                        <script>
                            document.getElementById('cancelButton').addEventListener('click', function() {
                                document.getElementById('searchForm').reset(); // Reset form fields
                                window.location.href = "<?php echo e(route('products.index')); ?>"; // Refresh the page
                            });
                        </script>

                        <?php if($products->isEmpty()): ?>
                            <div class="alert alert-warning text-center no-records">
                                <strong>No Records Found</strong> — Please try a different search.
                            </div>
                        <?php else: ?>
                            <table class="table table-striped table-bordered">
                                <thead style="text-align: center;">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Category</th>
                                        <th>Image</th>
                                        <th>Price (MRP)</th>
                                        <th>Discount</th>
                                        <th>Discounted Price</th>
                                        <th>Status</th>
                                        <th style="width:310px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product->id); ?></td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->description); ?></td>
                                            <td><?php echo e($product->category ? $product->category->name : 'N/A'); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($product->image)); ?>" alt="Product Image"
                                                    style="width: 100px; padding:5px; height: 100px; margin:auto;" />
                                            </td>
                                            <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                                            <td><?php echo e($product->discount ? $product->discount . '%' : 'N/A'); ?></td>
                                            <td style="text-align: center;">
                                                $<?php echo e(number_format($product->price - ($product->price * $product->discount) / 100, 2)); ?>

                                            </td>
                                            <td><?php echo e($product->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('products.toggleStatus', $product->id)); ?>"
                                                    method="POST" class="d-inline" onsubmit="return confirmToggle();">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit"
                                                        class="btn btn-<?php echo e($product->status ? 'warning' : 'success'); ?>"
                                                        title="<?php echo e($product->status ? 'Active' : 'Inactive'); ?>">
                                                        <?php echo e($product->status ? 'Inactive' : 'Active'); ?>

                                                    </button>
                                                </form>
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                                    class="btn btn-primary" title="Edit">Edit</a>
                                                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info"
                                                    title="View">View</a>
                                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST"
                                                    onsubmit="return confirmDelete();" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger"
                                                        title="Delete">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <script>
                            function confirmDelete() {
                                return confirm('Are you sure you want to delete this Product? This action cannot be undone.');
                            }

                            function confirmToggle() {
                                return confirm('Are you sure you want to change the visibility of this Product?');
                            }
                        </script>

                        <?php echo e($products->links()); ?> <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .no-records {
        padding: 20px;
        border: 1px solid #ffc107;
        border-radius: 5px;
        background-color: #fff3cd;
        color: #856404;
        margin-top: 20px;
        font-weight: bold;
        font-size: 1.2rem;
        text-align: center;
    }
</style>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/product/index.blade.php ENDPATH**/ ?>
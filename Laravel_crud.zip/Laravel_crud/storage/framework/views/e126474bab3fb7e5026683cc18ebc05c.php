<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(session('Status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="flash-alert"
                        style="position: relative; padding: 20px; border-radius: 5px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; margin-bottom: 20px; z-index: 1000;">
                        <strong>Success!</strong> <?php echo e(session('Status')); ?>

                        <button type="button" class="close" aria-label="Close"
                            style="position: absolute; top: 2px; right: 20px; font-size: 40px; color: #155724;"
                            onclick="hideAlert()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script>
                        function hideAlert() {
                            $('#flash-alert').fadeOut();
                        }

                        // Automatically hide the alert after 2 seconds
                        setTimeout(hideAlert, 2000);
                    </script>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h4>Student List
                            <a href="<?php echo e(url('students/create')); ?>" class="btn btn-primary float-end">Add Student</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered" style="justify-content: center;">
                            <thead style="text-align: center;">
                                <tr>
                                    <th>Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th style="width: 200px;">Profile Image</th>
                                    <th>Address</th>
                                    
                                    
                                    <th style="width: 250px;">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($student->id); ?></td>
                                        <td><?php echo e($student->first_name); ?></td>
                                        <td><?php echo e($student->last_name); ?></td>
                                        <td><?php echo e($student->email); ?></td>
                                        <td><?php echo e($student->phone_number); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($student->profile_picture)); ?>" alt="Profile Picture"
                                                class="img-fluid "
                                                style="width: 100px; padding:5px; height: 100px; margin:auto;" />
                                        </td>
                                        <td><?php echo e($student->address); ?></td>
                                        
                                        
                                        <td>

                                            <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary"
                                                title="Edit">
                                                Edit
                                            </a>
                                            <a href="<?php echo e(route('students.show', $student->id)); ?>" class="btn btn-info"
                                                title="View">
                                                View
                                            </a>
                                            <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST"
                                                onsubmit="return confirmDelete();" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger" title="Delete">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>

                                        <script>
                                            function confirmDelete() {
                                                return confirm('Are you sure you want to delete this category? This action cannot be undone.');
                                            }

                                            function confirmToggle() {
                                                return confirm('Are you sure you want to change the visibility of this category?');
                                            }
                                        </script>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                        <?php echo e($students->links()); ?> <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel_crud/resources/views/student/index.blade.php ENDPATH**/ ?>
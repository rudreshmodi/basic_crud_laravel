@extends('layouts.frontend')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Product
                            <a href="{{ url('products') }}" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('products.update', $product->id) }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            @method('PUT') <!-- Use PUT for updating -->
                            <div class="row">
                                <div class="col-lg-6">
                                    <label>Name</label>
                                    <input type=" text" class="form-control" name="name"
                                        value="{{ old('name', $product->name) }}" placeholder="Enter product name"
                                        required />
                                    @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label>Category</label>
                                    <select name="category_id" class="form-control" required>
                                        <option value="" disabled selected>Select a category</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}"
                                                {{ $product->category_id == $category->id ? 'selected' : '' }}>
                                                {{ $category->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('category_id')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-12">
                                    <label>Description</label>
                                    <textarea name="description" rows="3" class="form-control" placeholder="Enter product description" required>{{ old('description', $product->description) }}</textarea>
                                    @error('description')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Price ($)</label>
                                    <input type=" text" class="form-control" name="price"
                                        value="{{ old('price', $product->price) }}" placeholder="Enter price" required />
                                    @error('price')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label>Discount (%)</label>
                                    <input type=" text" class="form-control" name="discount"
                                        value="{{ old('discount', $product->discount) }}" placeholder="Enter discount" />
                                    @error('discount')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-3 pt-2">
                                    <label>Product Image</label>
                                    @if ($product->image)
                                        <div>
                                            <img src="{{ asset($product->image) }}" alt="Product Image"
                                                style="width: 100px; height: auto;" />
                                        </div>
                                    @else
                                        <p>No image uploaded</p>
                                    @endif
                                </div>
                                <div class="col-lg-9 pt-2">
                                    <label for="image" class="mt-2">Product Image (optional)</label>
                                    <input type="file" class="form-control" style="border:1px solid black; padding:5px;"
                                        name="image" accept="image/*" />
                                    @error('image')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <small class="form-text text-muted">Leave blank to keep current picture.</small>

                                </div>
                            </div>
                            <div class="row mt-4">
                                <div class="col-lg-12 text-end">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

<style>
    .row {
        padding: 10px;
    }
</style>

@extends('layouts.frontend')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                @if (session('Status'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="flash-alert"
                        style="position: relative; padding: 20px; border-radius: 5px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; margin-bottom: 20px; z-index: 1000;">
                        <strong>Success!</strong> {{ session('Status') }}
                        <button type="button" class="close" aria-label="Close"
                            style="position: absolute; top: 2px; right: 20px; font-size: 40px; color: #155724;"
                            onclick="hideAlert()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script>
                        function hideAlert() {
                            $('#flash-alert').fadeOut();
                        }

                        // Automatically hide the alert after 2 seconds
                        setTimeout(hideAlert, 2000);
                    </script>
                @endif

                <div class="card">
                    <div class="card-header">
                        <h4>Student List
                            <a href="{{ url('students/create') }}" class="btn btn-primary float-end">Add Student</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered" style="justify-content: center;">
                            <thead style="text-align: center;">
                                <tr>
                                    <th>Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th style="width: 200px;">Profile Image</th>
                                    <th>Address</th>
                                    {{-- <th>Bio</th> --}}
                                    {{-- <th>Role</th> --}}
                                    <th style="width: 250px;">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                @foreach ($students as $student)
                                    <tr>
                                        <td>{{ $student->id }}</td>
                                        <td>{{ $student->first_name }}</td>
                                        <td>{{ $student->last_name }}</td>
                                        <td>{{ $student->email }}</td>
                                        <td>{{ $student->phone_number }}</td>
                                        <td>
                                            <img src="{{ asset($student->profile_picture) }}" alt="Profile Picture"
                                                class="img-fluid "
                                                style="width: 100px; padding:5px; height: 100px; margin:auto;" />
                                        </td>
                                        <td>{{ $student->address }}</td>
                                        {{-- <td>{{ $student->bio }}</td> --}}
                                        {{-- <td>{{ ucfirst($student->role) }}</td> --}}
                                        <td>

                                            <a href="{{ route('students.edit', $student->id) }}" class="btn btn-primary"
                                                title="Edit">
                                                Edit
                                            </a>
                                            <a href="{{ route('students.show', $student->id) }}" class="btn btn-info"
                                                title="View">
                                                View
                                            </a>
                                            <form action="{{ route('students.destroy', $student->id) }}" method="POST"
                                                onsubmit="return confirmDelete();" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger" title="Delete">
                                                    Delete
                                                </button>
                                            </form>
                                        </td>

                                        <script>
                                            function confirmDelete() {
                                                return confirm('Are you sure you want to delete this category? This action cannot be undone.');
                                            }

                                            function confirmToggle() {
                                                return confirm('Are you sure you want to change the visibility of this category?');
                                            }
                                        </script>
                                    </tr>
                                @endforeach
                            </tbody>

                        </table>

                        {{ $students->links() }} <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@extends('layouts.frontend')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Student
                            <a href="{{ route('students.index') }}" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('students.update', $student->id) }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            @method('PUT') <!-- Add this line for updating -->

                            <div class="row">
                                <div class="col-lg-6">
                                    <label>First Name</label>
                                    <input type=" text" class="form-control" name="first_name"
                                        placeholder="Enter first name" value="{{ old('first_name', $student->first_name) }}"
                                        required />
                                    @error('first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label>Last Name</label>
                                    <input type=" text" class="form-control" name="last_name"
                                        placeholder="Enter last name" value="{{ old('last_name', $student->last_name) }}"
                                        required />
                                    @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Email</label>
                                    <input type=" email" class="form-control" name="email"
                                        placeholder="Enter email address" value="{{ old('email', $student->email) }}"
                                        required />
                                    @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label>Password</label>
                                    <input type=" password" class="form-control" name="password"
                                        placeholder="Enter password" />
                                    @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <small class="form-text text-muted">Leave blank to keep current password.</small>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Phone Number</label>
                                    <input type=" text" class="form-control" name="phone_number"
                                        placeholder="Enter phone number"
                                        value="{{ old('phone_number', $student->phone_number) }}" required />
                                    @error('phone_number')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label>Type</label>
                                    <select class="form-select" name="role" required>
                                        <option value="" disabled>Select Type</option>
                                        <option value="user"
                                            {{ old('role', $student->role) == 'user' ? 'selected' : '' }}>User</option>
                                        <option value="admin"
                                            {{ old('role', $student->role) == 'admin' ? 'selected' : '' }}>Admin</option>
                                    </select>
                                    @error('role')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-lg-6">
                                    <label>Address</label>
                                    <textarea name="address" rows="3" class="form-control" placeholder="Enter address" required>{{ old('address', $student->address) }}</textarea>
                                    @error('address')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6">
                                    <label>Bio</label>
                                    <textarea name="bio" rows="3" class="form-control" placeholder="Enter bio">{{ old('bio', $student->bio) }}</textarea>
                                </div>

                            </div>

                            <div class="row mt-3">
                                <div class="col-lg-3">
                                    <label>Profile Image</label>
                                    @if ($student->profile_picture)
                                        <div class="mb-2">
                                            <img src="{{ asset($student->profile_picture) }}" alt="Current Profile Image"
                                                style="width: 100px; height: auto;" />
                                        </div>
                                    @else
                                        <p>No current Image.</p>
                                    @endif
                                </div>
                                <div class="col-lg-9">
                                    <label>Profile Image(optional)</label>
                                    <input type="file" class="form-control" style="border: 1px solid gray; padding: 8px;"
                                        name="profile_picture" accept="image/*" />
                                    @error('profile_picture')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                    <small class="form-text text-muted">Leave blank to keep current picture.</small>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-lg-12 text-end">
                                    <button type="submit" class="btn btn-primary">
                                        Update
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

<style>
    .row {
        padding: 10px;
    }
</style>

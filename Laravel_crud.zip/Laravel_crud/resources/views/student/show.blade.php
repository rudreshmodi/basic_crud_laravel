@extends('layouts.frontend')

@section('content')
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-lg border-0 rounded">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Student Details</h4>
                    </div>
                    <div class="card-body">
                        <div class="row align-items-center m-auto">
                            <div class="col-md-4 text-center ">
                                @if ($student->profile_picture)
                                    <img src="{{ asset($student->profile_picture) }}" alt="Profile Image"
                                        class="rounded-circle m-auto" style="width: 200px; height: 200px;">
                                @else
                                    <img src="{{ asset('default-profile.png') }}" alt="Default Image" class="rounded-circle"
                                        style="width: 100px; height: 100px;">
                                @endif
                            </div>
                            <div class="col-md-8">
                                <h5>{{ $student->first_name }} {{ $student->last_name }}</h5>
                                <p class="text-muted">{{ $student->email }}</p>
                                <div>
                                    <strong>Phone Number:</strong> {{ $student->phone_number }}<br>
                                    <strong>Type:</strong> {{ ucfirst($student->role) }}<br>
                                    <strong>Address:</strong> {{ $student->address }}<br>
                                    <strong>Bio:</strong> {{ $student->bio }}
                                </div>
                            </div>
                        </div>
                        <div class="text-end mt-3">
                            <a href="{{ route('students.index') }}" class="btn btn-danger">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

<style>
    body {
        background-color: #f8f9fa;
    }

    .card {
        border-radius: 15px;
    }

    .card-header {
        font-size: 1.5rem;
        font-weight: bold;
    }

    .text-muted {
        font-size: 0.9rem;
    }

    .mb-3 {
        margin-bottom: 1.5rem !important;
    }

    .rounded-circle {
        border: 3px solid #007bff;
    }
</style>

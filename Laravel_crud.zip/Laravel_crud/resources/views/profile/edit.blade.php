<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Profile') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <!-- Profile Information Section -->
            <div class="p-6 bg-white dark:bg-gray-800 shadow rounded-lg">
                <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Profile Information</h3>
                <div class="max-w-xl">
                    @include('profile.partials.update-profile-information-form')
                </div>
            </div>

            <!-- Password Update Section -->
            <div class="p-6 bg-white dark:bg-gray-800 shadow rounded-lg">
                <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Update Password</h3>
                <div class="max-w-xl">
                    @include('profile.partials.update-password-form')
                </div>
            </div>

            <!-- Delete Account Section -->
            <div class="p-6 bg-white dark:bg-gray-800 shadow rounded-lg">
                <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">Delete Account</h3>
                <div class="max-w-xl">
                    @include('profile.partials.delete-user-form')
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Additional custom styles */
        h3 {
            border-bottom: 2px solid #e2e8f0;
            /* Add a subtle bottom border */
            padding-bottom: 10px;
            /* Space between title and content */
        }

        .bg-white {
            transition: background-color 0.3s ease;
            /* Smooth transition for dark mode */
        }

        .bg-gray-800 {
            transition: background-color 0.3s ease;
            /* Smooth transition for light mode */
        }

        /* Button styles */
        button {
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        button:hover {
            background-color: #2b6cb0;
            /* Change to a darker shade on hover */
            color: white;
            /* Change text color */
        }
    </style>
</x-app-layout>

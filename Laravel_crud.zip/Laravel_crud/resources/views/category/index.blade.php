@extends('layouts.frontend')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                @if (session('Status'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="flash-alert"
                        style="position: relative; padding: 20px; border-radius: 5px; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; margin-bottom: 20px; z-index: 1000;">
                        <strong>Success!</strong> {{ session('Status') }}
                        <button type="button" class="close" aria-label="Close"
                            style="position: absolute; top: 2px; right: 20px; font-size: 40px; color: #155724;"
                            onclick="hideAlert()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script>
                        function hideAlert() {
                            $('#flash-alert').fadeOut();
                        }
                        setTimeout(hideAlert, 2000);
                    </script>
                @endif

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4>Category List</h4>
                        <div>
                            <a href="{{ url('category/create') }}" class="btn btn-primary">Add Category</a>
                            <a href="{{ route('categories.export') }}" class="btn btn-outline-success ml-2">Download PDF</a>
                        </div>
                    </div>

                    <div class="card-body">
                        <form method="GET" action="{{ route('category.index') }}" class="mb-3" id="searchForm">
                            <div class="row">
                                <div class="col-lg-5">
                                    <input name="search" class="form-control" placeholder="Search by name"
                                        value="{{ request('search') }}">
                                </div>
                                <div class="col-lg-5">
                                    <select name="status" class="form-select">
                                        <option value="" disabled selected>Search by status</option>
                                        <option value="1" {{ request('status') == '1' ? 'selected' : '' }}>Active
                                        </option>
                                        <option value="0" {{ request('status') === '0' ? 'selected' : '' }}>
                                            Inactive</option>
                                    </select>
                                </div>
                                <div class="col-lg-1">
                                    <button class="btn btn-outline-primary w-100" type="submit">Search</button>
                                </div>
                                <div class="col-lg-1">
                                    <button class="btn btn-secondary w-100" type="button" id="cancelButton">Cancel</button>
                                </div>
                            </div>
                        </form>

                        <script>
                            document.getElementById('cancelButton').addEventListener('click', function() {
                                document.getElementById('searchForm').reset(); // Reset form fields
                                window.location.href = "{{ route('category.index') }}"; // Refresh the page
                            });
                        </script>

                        @if ($categories->isEmpty())
                            <div class="alert alert-warning text-center no-records">
                                <strong>No Records Found</strong> — Please try a different search.
                            </div>
                        @else
                            <table class="table table-striped table-bordered">
                                <thead class="table-light" style="text-align: center;">
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th style="width:350px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody style="text-align: center;">
                                    @foreach ($categories as $category)
                                        <tr>
                                            <td>{{ $category->id }}</td>
                                            <td>{{ $category->name }}</td>
                                            <td>{{ $category->description }}</td>
                                            <td>{{ $category->status == 1 ? 'Active' : 'Inactive' }}</td>
                                            <td>
                                                <form action="{{ route('category.toggleStatus', $category->id) }}"
                                                    method="POST" class="d-inline" onsubmit="return confirmToggle();">
                                                    @csrf
                                                    @method('PATCH')
                                                    <button type="submit"
                                                        class="btn btn-{{ $category->status ? 'warning' : 'success' }}"
                                                        title="{{ $category->status ? 'Inactive' : 'Active' }}">
                                                        {{ $category->status ? 'Inactivate' : 'Activate' }}
                                                    </button>
                                                </form>
                                                <a href="{{ route('category.edit', $category->id) }}"
                                                    class="btn btn-primary" title="Edit">Edit</a>
                                                <a href="{{ route('category.show', $category->id) }}" class="btn btn-info"
                                                    title="View">View</a>
                                                <form action="{{ route('category.destroy', $category->id) }}"
                                                    method="POST" onsubmit="return confirmDelete();" class="d-inline">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger"
                                                        title="Delete">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        @endif

                        <script>
                            function confirmDelete() {
                                return confirm('Are you sure you want to delete this category? This action cannot be undone.');
                            }

                            function confirmToggle() {
                                return confirm('Are you sure you want to change the visibility of this category?');
                            }
                        </script>

                        {{ $categories->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

<style>
    .row {
        padding: 10px;
    }

    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }

    .btn-outline-secondary {
        transition: background-color 0.3s ease;
    }

    .btn-outline-secondary:hover {
        background-color: #e2e6ea;
    }

    .no-records {
        padding: 20px;
        border: 1px solid #ffc107;
        border-radius: 5px;
        background-color: #fff3cd;
        color: #856404;
        margin-top: 20px;
        font-weight: bold;
        font-size: 1.2rem;
        text-align: center;
    }
</style>

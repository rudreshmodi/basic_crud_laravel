<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    {{-- <div class="py-5">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">
                <div class="text-gray-900 dark:text-gray-100 mb-6">
                    {{ __("You're logged in!") }}
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <!-- Card 1 -->
                    <div class="bg-blue-500 dark:bg-blue-700 text-black p-4 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold">Total Users</h3>
                        <p class="text-2xl font-bold">1,234</p>
                    </div>

                    <!-- Card 2 -->
                    <div class="bg-green-500 dark:bg-green-700 text-black p-4 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold">Active Sessions</h3>
                        <p class="text-2xl font-bold">456</p>
                    </div>

                    <!-- Card 3 -->
                    <div class="bg-yellow-500 dark:bg-yellow-700 text-black p-4 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold">New Messages</h3>
                        <p class="text-2xl font-bold">12</p>
                    </div>

                    <!-- Card 4 -->
                    <div class="bg-red-500 dark:bg-red-700 text-black p-4 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold">Pending Tasks</h3>
                        <p class="text-2xl font-bold">7</p>
                    </div>

                    <!-- Card 5 -->
                    <div class="bg-purple-500 dark:bg-purple-700 text-black p-4 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold">System Health</h3>
                        <p class="text-2xl font-bold">Good</p>
                    </div>

                    <!-- Card 6 -->
                    <div class="bg-indigo-500 dark:bg-indigo-700 text-black p-4 rounded-lg shadow-lg">
                        <h3 class="text-lg font-semibold">Latest Activity</h3>
                        <p class="text-2xl font-bold">3 Actions</p>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}


</x-app-layout>

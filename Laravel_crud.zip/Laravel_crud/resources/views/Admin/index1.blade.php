@extends('layouts.backend')

@section('content')
    <div class="container">
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="m-0 text-white">User List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                @foreach ($users as $user)
                                    <tr>
                                        <td>{{ $user->id }}</td>
                                        <td>{{ $user->name }}</td>
                                        <td>{{ $user->email }}</td>
                                        <td>{{ $user->role }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="{{ route('Admin.index') }}" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="m-0 text-white">Product List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Price (MRP)</th>
                                    <th>Discount</th>
                                    <th>Discounted Price</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                @foreach ($products as $product)
                                    <tr>
                                        <td>{{ $product->id }}</td>
                                        <td>{{ $product->name }}</td>
                                        <td>
                                            <img src="{{ asset($product->image) }}" alt="Product Image"
                                                class="product-image" />
                                        </td>
                                        <td>{{ $product->description }}</td>
                                        <td>{{ $product->category ? $product->category->name : 'N/A' }}</td>
                                        <td>${{ number_format($product->price, 2) }}</td>
                                        <td>{{ $product->discount ? $product->discount . '%' : 'N/A' }}</td>
                                        <td>${{ number_format($product->price * (1 - $product->discount / 100), 2) }}</td>
                                        <td>{{ $product->status == 1 ? 'Active' : 'Inactive' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="{{ route('products.index') }}" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="m-0 text-white">Category List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                @foreach ($categories as $category)
                                    <tr>
                                        <td>{{ $category->id }}</td>
                                        <td>{{ $category->name }}</td>
                                        <td>{{ $category->description }}</td>
                                        <td>{{ $category->status == 1 ? 'Active' : 'Inactive' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="{{ route('category.index') }}" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card shadow-lg border-0">
                    <div class="card-header">
                        <h4>Student List</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead class="text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Profile Image</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Address</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                @foreach ($students as $student)
                                    <tr>
                                        <td>{{ $student->id }}</td>
                                        <td>{{ $student->first_name }}</td>
                                        <td>{{ $student->last_name }}</td>
                                        <td>
                                            <img src="{{ asset($student->profile_picture) }}" alt="Profile Picture"
                                                class="Student-image" />
                                        </td>
                                        <td>{{ $student->email }}</td>
                                        <td>{{ $student->phone_number }}</td>

                                        <td>{{ $student->address }}</td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="text-center float-end">
                            <a href="{{ route('students.index') }}" class="btn btn-primary">See More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .card {
            border-radius: 15px;
            transition: transform 0.2s;
        }

        .card:hover {
            transform: scale(1.02);
        }

        .card-header {
            background: linear-gradient(to right, #4e73df, #224abe);
            color: white;
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: #f8f9fa;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .product-image,
        .Student-image {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            margin: auto;
            border: 1px solid #007bff;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s, color 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            color: white;
        }

        img.img-fluid {
            width: 100px;
            height: auto;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .card-header h4 {
                font-size: 1.2rem;
            }
        }
    </style>
@endsection

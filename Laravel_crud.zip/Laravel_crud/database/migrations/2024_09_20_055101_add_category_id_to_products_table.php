<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            // Check if the column does not already exist
            if (!Schema::hasColumn('products', 'category_id')) {
                // Add category_id as a foreign key
                $table->foreignId('category_id')
                    ->constrained('categories') // Establish foreign key relationship
                    ->onDelete('cascade') // Handle cascading deletes
                    ->after('description'); // Position the column after 'description'
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            // Check if the column exists before dropping it
            if (Schema::hasColumn('products', 'category_id')) {
                $table->dropForeign(['category_id']); // Drop foreign key constraint
                $table->dropColumn('category_id'); // Drop the column
            }
        });
    }
};
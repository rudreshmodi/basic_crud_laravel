<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id(); // Auto-incrementing ID
            $table->string('name'); // String type for product name
            $table->text('description'); // Use text for longer descriptions
            $table->foreignId('category_id') // Foreign key to categories
                ->constrained('categories') // Reference to categories table
                ->onDelete('cascade'); // Cascade delete if category is deleted
            $table->decimal('price', 10, 2); // Decimal for price with 2 decimal places
            $table->decimal('discount', 5, 2)->nullable(); // Discount can be nullable
            $table->string('image')->nullable(); // Image path can be nullable
            $table->boolean('status')->default(1)->comment('1=visible, 0=hidden'); // Default visibility status
            $table->timestamps(); // Created at and updated at timestamps
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products'); // Drop the products table if it exists
    }
};
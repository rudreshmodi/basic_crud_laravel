<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    // Specify the table name if it's different from the plural of the model name
    protected $table = 'students';

    // Specify which attributes should be mass assignable
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'phone_number',
        'profile_picture',
        'address',
        'bio',
        'role',
    ];

    // Optionally, if you have timestamps enabled in your database
    public $timestamps = true;

    // If you want to hide sensitive information, like passwords
    protected $hidden = [
        'remember_token',
    ];
}
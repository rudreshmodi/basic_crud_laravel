<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    // Specify the table name if it doesn't follow Laravel's naming convention
    protected $table = 'products';

    // Define the fillable attributes for mass assignment
    protected $fillable = [
        'name',
        'description',
        'category_id', // Change this to category_id to match your database
        'price',
        'discount',
        'image',
        'status', // Uncomment this if you want to allow mass assignment for status
    ];

    // Define the relationship with the Category model
    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}
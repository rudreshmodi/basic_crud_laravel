<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Student;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of users with their roles.
     */
    public function index()
    {
        $users = User::all(); // Fetch all users
        $users = User::paginate(10); // Adjust pagination as needed
        return view('Admin.index', compact('users')); // Return view with users
    }
    public function index1()
    {
        $users = User::all(); // Fetch all users
        $products = Product::all(); // Fetch all products (or whatever data you need)
        $categories = Category::all();
        $students = Student::all();

        $users = User::orderBy('created_at', 'desc')->paginate(5);
        $products = Product::orderBy('created_at', 'desc')->paginate(5);
        $categories = Category::orderBy('created_at', 'desc')->paginate(5);
        $students = Student::orderBy('created_at', 'desc')->paginate(5);


        return view('Admin.index1', compact('users', 'products', 'categories', 'students')); // Return view with users
    }
    /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        return view('Admin.create'); // Return view for creating a user
    }

    /**
     * Store a newly created user in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|string',
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'role' => $request->role,
        ]);

        return redirect()->route('Admin.index')->with('Status', 'User created successfully!');
    }

    /**
     * Show the form for editing the specified user.
     */
    public function edit(User $user)
    {
        return view('Admin.edit', compact('user')); // Return view for editing a user
    }

    /**
     * Update the specified user in storage.
     */
    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                // Unique rule only if the email has changed
                \Illuminate\Validation\Rule::unique('users')->ignore($user->id),
            ],
            'password' => 'nullable|string|min:8|confirmed', // Make password optional
            'role' => 'required|string',
        ]);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->role = $request->role;

        // Update password only if it is provided
        if ($request->filled('password')) {
            $user->password = bcrypt($request->password);
        }

        $user->save(); // Save the updated user data

        return redirect()->route('Admin.index')->with('Status', 'User updated successfully!');
    }

    /**
     * Remove the specified user from storage.
     */
    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('Admin.index')->with('Status', 'User deleted successfully!');
    }
}

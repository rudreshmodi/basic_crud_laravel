<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Barryvdh\DomPDF\Facade as PDF;
use Barryvdh\DomPDF\Facade\Pdf as FacadePdf;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Category::query();

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%')->paginate(10);;
        }

        if ($request->has('status')) {
            $query->where('status', $request->status)->paginate(10);;
        }

        $categories = $query->paginate(10);

        if ($request->ajax()) {
            return view('category.index', compact('categories'));
        }

        return view('category.index', compact('categories'));
    }



    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('category.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:255',
            'status' => 'nullable',

        ]);
        Category::create(
            [
                'name' => $request->name,
                'description' => $request->description,
                'status' => $request->status == true ? 1 : 0,
            ]
        );
        return redirect()->route('category.index')->with('Status', 'Category created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(Category $category)
    {
        return view('category.show', compact('category'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category $category)
    {
        return view('category.edit', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Category $category)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:255',
            'status' => 'nullable',

        ]);
        $category->update(
            [
                'name' => $request->name,
                'description' => $request->description,
                'status' => $request->status == true ? 1 : 0,
            ]
        );
        return redirect()->route('category.index')->with('Status', 'Category updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        $category->delete();
        return redirect()->route('category.index')->with('Status', 'Category deleted successfully');
    }

    // Inside CategoryController

    /**
     * Toggle the visibility status of the specified category.
     */
    public function toggleStatus($id)
    {
        $category = Category::findOrFail($id);
        $category->status = !$category->status; // Toggle status
        $category->save();

        return redirect()->route('category.index')->with('Status', 'Category status updated successfully');
    }

    public function export(Request $request)
    {
        // Initialize the query
        $query = Category::query();

        // Check for search term in the request
        if ($request->has('search') && $request->search) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Retrieve the filtered categories
        $categories = $query->get();

        // Load a view and pass the data to it
        $pdf = FacadePdf::loadView('category.export', ['categories' => $categories]);

        // Set the filename
        $pdfFileName = 'categories_' . date('Ymd') . '.pdf';

        // Return the PDF as a downloadable response
        return $pdf->download($pdfFileName);
    }
}
<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category; // Import the Category model
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Product::query();

        // Search by name
        if ($request->has('name') && $request->input('name') !== '') {
            $searchName = $request->input('name');
            $query->where('name', 'like', '%' . $searchName . '%');
        }

        // Search by category (you may need to join with categories table)
        if ($request->has('category') && $request->input('category') !== '') {
            $searchCategory = $request->input('category');
            $query->whereHas('category', function ($q) use ($searchCategory) {
                $q->where('name', 'like', '%' . $searchCategory . '%');
            });
        }

        // Search by status
        if ($request->has('status') && $request->input('status') !== '') {
            $query->where('status', $request->input('status'));
        }

        // Fetch products with pagination
        $products = $query->paginate(10); // Adjust pagination as needed

        return view('product.index', compact('products'));
    }




    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::where('status', 1)->get(); // Fetch visible categories
        return view('product.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id', // Validate category_id
            'price' => 'required|numeric',
            'discount' => 'nullable|numeric',
            'image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        $imagePath = null;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('product'), $imageName);
            $imagePath = 'product/' . $imageName;
        }

        Product::create([
            'name' => $request->name,
            'description' => $request->description,
            'category_id' => $request->category_id, // Ensure this is included
            'price' => $request->price,
            'discount' => $request->discount,
            'image' => $imagePath,
        ]);

        return redirect()->route('products.index')->with('Status', 'Product created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        return view('product.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $categories = Category::where('status', 1)->get(); // Fetch visible categories
        return view('product.edit', compact('product', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Product $product)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'category_id' => 'required|exists:categories,id', // Validate category_id
            'price' => 'required|numeric',
            'discount' => 'nullable|numeric',
            'image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048', // Validate the image
        ]);

        $imagePath = $product->image; // Keep existing image path

        if ($request->hasFile('image')) {
            // Delete the old image if it exists
            if ($imagePath) {
                $oldImagePath = public_path($imagePath);
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath); // Delete old image file
                }
            }
            // Store the new image
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('product'), $imageName); // Store in public/product
            $imagePath = 'product/' . $imageName; // Save new relative path
        }

        $product->update([
            'name' => $request->name,
            'description' => $request->description,
            'category_id' => $request->category_id, // Update category_id
            'price' => $request->price,
            'discount' => $request->discount,
            'image' => $imagePath, // Update image path
        ]);

        return redirect()->route('products.index')->with('Status', 'Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        // Optionally delete the image file before deleting the product
        if ($product->image) {
            $imagePath = public_path($product->image);
            if (file_exists($imagePath)) {
                unlink($imagePath); // Delete the image file
            }
        }

        $product->delete();
        return redirect()->route('products.index')->with('Status', 'Product deleted successfully');
    }
    // Inside ProductController

    /**
     * Toggle the visibility status of the specified resource.
     */
    public function toggleStatus($id)
    {
        $product = Product::findOrFail($id);
        $product->status = !$product->status; // Toggle status
        $product->save();

        return redirect()->route('products.index')->with('Status', 'Product status updated successfully');
    }
}
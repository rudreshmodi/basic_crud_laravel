<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $students = Student::paginate(5); // Adjust pagination as needed
        return view('student.index', ['students' => $students]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('student.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:students',
            'password' => 'required|string|min:8', // Validate password
            'phone_number' => 'nullable|string|max:15', // Validate phone number
            'profile_picture' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'address' => 'nullable|string',
            'bio' => 'nullable|string',
            'role' => 'required|string|in:user,admin', // Validate role
        ]);

        $imagePath = null;

        if ($request->hasFile('profile_picture')) {
            $image = $request->file('profile_picture');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('student'), $imageName); // Store in public/student
            $imagePath = 'student/' . $imageName; // Save relative path
        }

        Student::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => bcrypt($request->password), // Hash the password
            'phone_number' => $request->phone_number,
            'profile_picture' => $imagePath,
            'address' => $request->address,
            'bio' => $request->bio,
            'role' => $request->role, // Store role
        ]);

        return redirect()->route('students.index')->with('Status', 'Student created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(Student $student)
    {
        return view('student.show', compact('student'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Student $student)
    {
        return view('student.edit', compact('student'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Student $student)
    {
        $request->validate([
            'first_name' => 'sometimes|required|string|max:255',
            'last_name' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|required|string|email|max:255|unique:students,email,' . $student->id,
            'password' => 'nullable|string|min:8', // Validate password if provided
            'phone_number' => 'nullable|string|max:15',
            'profile_picture' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'address' => 'nullable|string',
            'bio' => 'nullable|string',
            'role' => 'sometimes|required|string|in:user,admin', // Validate role
        ]);

        $imagePath = $student->profile_picture; // Keep existing image path

        if ($request->hasFile('profile_picture')) {
            // Delete the old image if it exists
            if ($imagePath) {
                $oldImagePath = public_path($imagePath);
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath); // Delete old image file
                }
            }
            // Store the new image
            $image = $request->file('profile_picture');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('student'), $imageName); // Store in public/student
            $imagePath = 'student/' . $imageName; // Save new relative path
        }

        $student->update([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => $request->password ? bcrypt($request->password) : $student->password, // Update password only if provided
            'phone_number' => $request->phone_number,
            'profile_picture' => $imagePath,
            'address' => $request->address,
            'bio' => $request->bio,
            'role' => $request->role, // Update role
        ]);

        return redirect()->route('students.index')->with('Status', 'Student updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Student $student)
    {
        // Optionally delete the profile picture before deleting the student
        if ($student->profile_picture) {
            $imagePath = public_path($student->profile_picture);
            if (file_exists($imagePath)) {
                unlink($imagePath); // Delete the image file
            }
        }

        $student->delete();
        return redirect()->route('students.index')->with('Status', 'Student deleted successfully');
    }
}